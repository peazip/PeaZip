PEAZIP THEMES
PeaZip 7+ version accepts as icon sources arbitrarily sized graphic saved as 32 bit or 8 bit PNG with transparency.
Icons will be scaled at runtime to be rendered fitting system's icon size (or approximate size that can be efficiently rendered), up to 10x zoom - in example a small icon can be rendered ranging from 16px to 160px.

DROID THEME
Droid theme provides icons meant for a look and feel quite familiar to users of mobile OSes and online apps.
Graphic is saved as 32 bit PNG with transparence.
Folder 16 contains 16px icons zoomed x3 (48px)
Folder 32 contains 32px icons zoomed x3 (96px)
Folder 48 contains non zoomed 48px icons
Folder 96 contains non zoomed 96px icons